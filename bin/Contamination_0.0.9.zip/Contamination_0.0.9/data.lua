data:extend(
{
  {
    type = "ambient-sound",
    name = "GeigerCounter",
    track_type = "interlude",
    sound =
    {
      filename = "__Contamination__/sounds/Geiger_panic.ogg"
    }
  }
})