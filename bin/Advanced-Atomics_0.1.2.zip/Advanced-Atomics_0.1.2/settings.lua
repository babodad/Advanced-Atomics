data:extend({
	{
        type = "bool-setting",
		name = "AA_enable-SSP4Plutonium",
		setting_type = "startup",
		default_value = true,
		order = "a-a"
	},
	{
        type = "bool-setting",
		name = "AA_enable-TreeMapColor",
		setting_type = "startup",
		default_value = false,
		order = "a-b"
	}
	
})