data:extend({
	{
        type = "bool-setting",
		name = "AA_enable-Plutonium",
		setting_type = "startup",
		default_value = true,
		order = "a-a"
	},
	{
        type = "bool-setting",
		name = "AA_enable-TreeMapColor",
		setting_type = "startup",
		default_value = false,
		order = "a-b"
	}
	
})