local anim_speed = 0.25

data:extend({
	{
		type = "explosion",
		name = "uranium-explosion-LUQ",
		flags = {"not-on-map"},
		animations =
		{
			{
				filename = "__MushroomCloud__/graphics/explosion/LUQ.png",
				priority = "extra-high",
				width = 256,
				height = 256,
				frame_count = 64,
				line_length = 8,
				scale = 4,
				shift = {-16, -16},
				animation_speed = anim_speed
			},
		},
		light = {intensity = 10, size = 120},
		smoke = "smoke-fast",
		smoke_count = 2,
		smoke_slow_down_factor = 1,
		sound =
		{
			aggregation =
			{
				max_count = 1,
				remove = false
			},
			variations =
			{
				{
					filename = "__MushroomCloud__/sound/nuclear_detonation_in_vincinity.ogg", -- only audible up to 40 tiles
					volume = 0.5
				},
			}
		},
	},
	{
		type = "explosion",
		name = "uranium-explosion-RUQ",
		flags = {"not-on-map"},
		animations =
		{
			{
				filename = "__MushroomCloud__/graphics/explosion/RUQ.png",
				priority = "extra-high",
				width = 256,
				height = 256,
				frame_count = 64,
				line_length = 8,
				scale = 4,
				shift = {16, -16},
				animation_speed = anim_speed
			},
		},
		light = {intensity = 10, size = 120},
		smoke = "smoke-fast",
		smoke_count = 2,
		smoke_slow_down_factor = 1,
		sound =
		{
			aggregation =
			{
				max_count = 1,
				remove = false
			},
			variations =
			{
				{
					filename = "__MushroomCloud__/sound/nuclear_detonation_in_vincinity.ogg",
					volume = 0.5
				},
			}
		},
	},
	{
		type = "explosion",
		name = "uranium-explosion-LLQ",
		flags = {"not-on-map"},
		animations =
		{
			{
				filename = "__MushroomCloud__/graphics/explosion/LLQ.png",
				priority = "extra-high",
				width = 256,
				height = 256,
				frame_count = 64,
				line_length = 8,
				scale = 4,
				shift = {-16, 16},
				animation_speed = anim_speed
			},
		},
		light = {intensity = 10, size = 120},
		smoke = "smoke-fast",
		smoke_count = 2,
		smoke_slow_down_factor = 1,
		sound =
		{
			aggregation =
			{
				max_count = 1,
				remove = false
			},
			variations =
			{	
				{
					filename = "__MushroomCloud__/sound/nuclear_detonation_in_vincinity.ogg",
					volume = 0.5,
				},
			}
		},
	},
	{
		type = "explosion",
		name = "uranium-explosion-RLQ",
		flags = {"not-on-map"},
		animations =
		{
			{
				filename = "__MushroomCloud__/graphics/explosion/RLQ.png",
				priority = "extra-high",
				width = 256,
				height = 256,
				frame_count = 64,
				line_length = 8,
				scale = 4,
				shift = {16, 16},
				animation_speed = anim_speed
			},
		},
		light = {intensity = 10, size = 120},
		smoke = "smoke-fast",
		smoke_count = 2,
		smoke_slow_down_factor = 1,
		sound =
		{
			aggregation =
			{
				max_count = 1,
				remove = false
			},
			variations =
			{
				{
					filename = "__MushroomCloud__/sound/nuclear_detonation_in_vincinity.ogg",
					volume = 0.5
				},
			}
		},
	}
})

data.raw["projectile"]["atomic-rocket"].action = {
    type = "direct",
    action_delivery =
    {
        type = "instant",
        target_effects =
        {
            {
                repeat_count = 100,
                type = "create-trivial-smoke",
                smoke_name = "nuclear-smoke",
                offset_deviation = {{-1, -1}, {1, 1}},
                slow_down_factor = 1,
                starting_frame = 3,
                starting_frame_deviation = 5,
                starting_frame_speed = 0,
                starting_frame_speed_deviation = 5,
                speed_from_center = 0.5,
                speed_deviation = 0.2
            },
            {
                type = "create-entity",
                entity_name = "explosion"
            },
            {
                type = "damage",
                damage = {amount = 400, type = "explosion"}
            },
            {
                type = "create-entity",
                entity_name = "uranium-explosion-LUQ",
                trigger_created_entity = "true"                
            },
            {
                type = "create-entity",
                entity_name = "uranium-explosion-RUQ"
            },
            {
                type = "create-entity",
                entity_name = "uranium-explosion-LLQ"
            },
            {
                type = "create-entity",
                entity_name = "uranium-explosion-RLQ"
            },
			{
                type = "create-entity",
                entity_name = "nuclear-scorchmark"
            },
            {
                type = "nested-result",
                action =
                {
                    type = "area",
                    target_entities = false,
                    repeat_count = 2000,
                    radius = 35,
                    action_delivery =
                    {
                        type = "projectile",
                        projectile = "atomic-bomb-wave",
                        starting_speed = 0.5
                    }
                }
            }
        }
    }
}	