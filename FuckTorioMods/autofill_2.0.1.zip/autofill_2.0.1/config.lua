--luacheck: globals AF DEBUG

local config = {
    DEBUG = false
}

return config
