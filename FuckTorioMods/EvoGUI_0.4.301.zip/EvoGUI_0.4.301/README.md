This is a [Factorio](http://www.factorio.com/) mod. It adds a small UI frame
that informs you of the current biter evolution level, as well as your play
time.


## Many thanks for ##

* The many downloads so far! Glad you guys are liking it.
* Continuous Integration by CircleCI: [![Circle CI](https://circleci.com/gh/narc0tiq/evoGUI.svg?style=svg)](https://circleci.com/gh/narc0tiq/evoGUI)
* Many, many improvements made by Afforess! Thanks so much, you're the best!
* The wonderful translations contributed by these awesome people:
    JoCKeRiL (Hebrew), Rikkilook (Russian), theRustyKnife (Czech),
    thomaskneisel and BenediktMagnus (German), diilmac (Polish),
    Xagros (Korean).


## License ##

The source of **EvoGUI** is Copyright 2015-2017 Octav "narc" Sandulescu. It
is licensed under the [MIT license][mit], available in this package in the file
[LICENSE.md](LICENSE.md).

[mit]: http://opensource.org/licenses/mit-license.html


## Statistics ##

78 exceptions were caught during the creation of this mod.
