--Set stack size of end game rocket items so satellite can be uncrafted
data.raw.item["low-density-structure"].stack_size = 50
data.raw.item["rocket-fuel"].stack_size = 50
data.raw.item["rocket-control-unit"].stack_size = 50
data.raw.item["rocket-part"].stack_size = 50