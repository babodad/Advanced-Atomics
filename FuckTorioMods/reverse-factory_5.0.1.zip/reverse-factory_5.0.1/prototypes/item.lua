data:extend({
--ITEM
{
    type = "item",
    name = "reverse-factory",
    icon = "__reverse-factory__/graphics/item/reverse-factory.png",
	icon_size = 32,
    flags = {"goes-to-quickbar"},
    subgroup = "smelting-machine",
    order = "d[reverse-factory]",
    place_result = "reverse-factory",
    stack_size = 10
}
})
