data:extend({
--For recipes with multiple outputs
{
    type = "item-group",
    name = "rf-multiple-outputs",
    order = "f",
    inventory_order = "f",
    icon = "__reverse-factory__/graphics/icon/module-tab.png",
	icon_size = 64
},

--For recipes with multiple outputs
{
    type = "item-subgroup",
    name = "rf-multiple-outputs",
    group = "rf-multiple-outputs",
    order = "a",
	icon_size = 64
}
})