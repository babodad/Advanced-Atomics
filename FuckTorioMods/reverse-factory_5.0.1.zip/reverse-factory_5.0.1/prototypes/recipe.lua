data:extend({
--RECIPE
{
    type = "recipe",
    name = "reverse-factory",
    enabled = "false",
    energy_required = 20,
    ingredients =
    {
        {"iron-plate", 30},
        {"iron-gear-wheel", 15}
    },
    result = "reverse-factory"
}
})
