data:extend({
	{
		type = "recipe-category",
		name = "recycle"
	},
	{
		type = "recipe-category",
		name = "recycle-with-fluid"
	}
})
