# reverse-factory
# Description
It's a mod for the game Factorio which add a new entity : the __Reverse Factory__.  
  
I based my work on the mod [__Recycling Plant__][recycling_plant].  
Therefore, the entity is still working as a furnace. Thereby, I take the decision to remove the property fuel_value of three items to allow them to be disassemble : __"wood"__, __"wooden-chest"__ and __"small-electric-pole"__  
  
The __Reverse Factory__ is a new version of the __Recycling Plant__ at the difference that every recipes of every mods are dynamically generated.  
   
Currently available and working for Factorio __0.13.x__   
  
For basic mods, I can't garantee but there should be no problem to generate the recipes.  
But for big mods that's another matter.  
  
Mods I personally tested :  
* Yuoki
  * Yuoki Industries
  * Yuoki Engines
* DyTech
  * CORE
  * Machine
  * Power
  * War
* TreeFarm Lite
* Bob's mods
  * bobassembly
  * bobelecoveride
  * bobenemies
  * boblogistics
  * bobmining
  * bobmodules
  * bobores
  * bobplates
  * bobpower
  * bobtech
  * bobwarfare
  
# License
  
This mod has no license.

[recycling_plant]: http://www.factorioforums.com/forum/viewtopic.php?f=87&t=10247
